package com.oblivioussp.spartanweaponry.compat.footworkapi;

/*import jackiecrazy.footwork.api.CombatDamageSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.player.Player;

public class FootworkHybridDamageSource
{
	public static DamageSource create(Player player, float armorPiercingPercentageIn, DamageSource originalSource)
	{
		if((originalSource instanceof CombatDamageSource combatSource))
			return combatSource.setArmorReductionPercentage(armorPiercingPercentageIn);
		else
			throw new IllegalArgumentException("Original DamageSource is not Footwork's CombatDamageSource!");
	}
}
*/