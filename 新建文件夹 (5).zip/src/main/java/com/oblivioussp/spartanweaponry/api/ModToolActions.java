package com.oblivioussp.spartanweaponry.api;

import com.oblivioussp.spartanweaponry.ModSpartanWeaponry;

import net.minecraftforge.common.ToolAction;

public class ModToolActions 
{
	public static final ToolAction MELEE_BLOCK = ToolAction.get(ModSpartanWeaponry.ID + ":melee_block");
}
