# SpartanWeaponry
Weapons Galore! A whole new arsenal of weaponry made for Minecraft.<br>
Inspired by Balkon's WeaponMod, it adds new versions of weapons from that mod, as well expanding the arsenal with a bunch of original weapons, including a variety of swords, polearms, blunt and ranged weapons<br>
Now open source under the Apache License 2.0!<br>
Find the mod pages below:<br>
CurseForge -> https://www.curseforge.com/minecraft/mc-mods/spartan-weaponry<br>
Modrinth -> https://modrinth.com/mod/spartan-weaponry